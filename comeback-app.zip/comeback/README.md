# Comeback — Sports Recovery App

Science-backed sports injury recovery protocols built around your sport, injury, and goals.

## Tech Stack

- **React 18** + **TypeScript**
- **Vite** (build tool)
- **Lucide React** (icons)
- Deployed via **Netlify**

## Local Development

```bash
# Install dependencies
npm install

# Start dev server
npm run dev
```

App runs at `http://localhost:5173`

## Build

```bash
npm run build
```

Output goes to `dist/` folder.

## Deploy to Netlify

### Option A — Netlify UI (recommended for first deploy)

1. Push this repo to GitHub
2. Go to [netlify.com](https://netlify.com) → **Add new site** → **Import an existing project**
3. Connect your GitHub and select this repo
4. Netlify auto-detects the settings from `netlify.toml`:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
5. Click **Deploy site** — done ✅

### Option B — Netlify CLI

```bash
npm install -g netlify-cli
netlify login
netlify init
netlify deploy --prod
```

## Notes

- `netlify.toml` handles SPA redirects so page refreshes never 404
- `NODE_VERSION = "20"` is pinned in `netlify.toml` for consistent builds
